export interface Author {
   id: number;
   name: string;
   birthday: string;
   bio: string;
   createdAt: string;
   updatedAt: string;
}